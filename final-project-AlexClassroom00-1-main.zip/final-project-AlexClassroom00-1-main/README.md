# final-project-AlexClassroom00-1
My final project will be a content sharing platform where registered users can post images or text posts that will be displayed on the homepage. Admin users will be able to delete posts and make news announcements. Users will be able to customize their profiles by adding Bios and profile pictures. 
