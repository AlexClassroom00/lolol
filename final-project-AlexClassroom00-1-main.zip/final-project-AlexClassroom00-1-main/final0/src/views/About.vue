<template>
  <div class="about">
    <h3><u>About Alex's Place</u></h3>
	<div class="aboutCont">
	<h4>Welcome to Alex's Place! Here you will be able to upload images for all to see!!</h4>
	</div>
  </div>
</template>

<style>

.aboutCont{
	margin: auto;
	width: 500px;
	outline: 2px solid #942ffa;
	padding: 10px;
	background: #e8e8e8;

} 

</style>