<template>
  <div class="home">
  <post></post>

  </div>
</template>

<script>
import post from './../components/userComp'



export default {
	name: 'userPost',
	components: {
	post
	},

}

</script>
<style>

img{
	max-width: 300px;
	

}



.home{
	margin: auto;
}

.break {
height: 1px;
width: 300px;
margin: auto;
background: #942ffa;
}
.postCont {
	outline: 2px solid #942ffa;
	padding: 10px;
	background: #e8e8e8;
	margin-bottom: 10px;

}

</style>